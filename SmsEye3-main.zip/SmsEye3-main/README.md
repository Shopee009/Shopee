<p align="center">
  <img src="/Images/banner.png" width="60%" />
</p>
<h3 align="center">Powerful tool to access android devices incoming SMS messages</h3>
<h4 align="center">This tool is made for educational purposes only!</h4>
<h3 align="center"> ‏‏‎ ‎</h3>

## 〽️ About SmsEye3
#### SmsEye3 is the latest version of SmsEyeseries which is a tool to access incoming SMS messages of target device.
#### In this version of SmsEye3 we switched admin interface from Telegram bot to live web panel.

## ❓ How it works
### SmsEye3 has 2 main sides:
#### Server side:
- NodeJS framework (backend)
- HTML/CSS/EJS (forntend)
#### Client side:
- Kotlin
- Jetpack compose

## 🌐 Features
- easy to use
- customizable
- multi target
- beautiful design

## 🎴 Screenshots
<p float="left">
  <img src="/Images/Screenshot1.png" width="100%" />
  <img src="/Images/Screenshot2.png" width="100%" />
</p>

## 💻 How to use
### If you are willing to use this tool, contact admin for more information:
[![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/abyssalarmy)
